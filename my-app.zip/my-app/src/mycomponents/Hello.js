import React from 'react'

function Hello(){
    return(<h1>I am from function component</h1>);
}

export default Hello